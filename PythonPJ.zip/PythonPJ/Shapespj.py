import cv2
import numpy as np
import argparse

def detect_shapes(image_path):
    img = cv2.imread(image_path)
    if img is None:
        print(f"Ошибка: Не удалось прочитать изображение {image_path}")
        return

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    _, threshold = cv2.threshold(blurred, 127, 255, cv2.THRESH_BINARY_INV)

    contours, _ = cv2.findContours(threshold, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:

        if cv2.contourArea(contour) < 50:
            continue

        epsilon = 0.02 * cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, epsilon, True)

        M = cv2.moments(contour)
        if M['m00'] != 0:
            x = int(M['m10'] / M['m00'])
            y = int(M['m01'] / M['m00'])
        else:
            x, y = 0, 0

        if len(approx) == 3:
            shape_name = 'Triangle'
        elif len(approx) == 4:
            (x, y, w, h) = cv2.boundingRect(approx)
            aspect_ratio = float(w) / h
            if 0.95 <= aspect_ratio <= 1.05:
                shape_name = 'Square'
            else:
                shape_name = 'Rectangle'
        elif len(approx) == 5:
            shape_name = 'Pentagon'
        elif len(approx) == 6:
            shape_name = 'Hexagon'
        else:
            area = cv2.contourArea(contour)
            perimeter = cv2.arcLength(contour, True)
            if perimeter == 0:
                continue
            circularity = 4 * np.pi * (area / (perimeter * perimeter))
            if circularity > 0.8:
                shape_name = 'Circle'
            else:
                shape_name = 'Unknown'

        cv2.drawContours(img, [contour], -1, (0, 255, 0), 3)
        cv2.putText(img, shape_name, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    cv2.imshow('C:\\Users\\student1\\Desktop\\PythonPJ\\Shapes.png')